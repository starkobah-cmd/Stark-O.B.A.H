var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_app = require("firebase/app");
var import_firestore = require("firebase/firestore");
var app = (0, import_express.default)();
var PORT = process.env.PORT || 3e3;
app.use(import_express.default.json({ limit: "50mb" }));
app.use(import_express.default.urlencoded({ extended: true, limit: "50mb" }));
var firestoreDb = null;
try {
  const configPath = import_path.default.join(process.cwd(), "firebase-applet-config.json");
  if (import_fs.default.existsSync(configPath)) {
    const firebaseConfig = JSON.parse(import_fs.default.readFileSync(configPath, "utf-8"));
    const fbApp = (0, import_app.initializeApp)(firebaseConfig);
    firestoreDb = (0, import_firestore.getFirestore)(fbApp, firebaseConfig.firestoreDatabaseId);
    console.log("Firebase Firestore connected successfully.");
  }
} catch (e) {
  console.warn("Firebase initialization skipped:", e);
}
var DB_FILE = import_path.default.join(process.cwd(), "data", "db.json");
function loadDb() {
  try {
    if (!import_fs.default.existsSync(import_path.default.dirname(DB_FILE))) {
      import_fs.default.mkdirSync(import_path.default.dirname(DB_FILE), { recursive: true });
    }
    if (import_fs.default.existsSync(DB_FILE)) {
      const content = import_fs.default.readFileSync(DB_FILE, "utf-8");
      return JSON.parse(content);
    }
  } catch (err) {
    console.error("Error reading db.json:", err);
  }
  return {
    posts: [
      {
        id: "post-core-web-vitals-playbook",
        title: "Mastering Core Web Vitals in 2026: The Definitive Speed Engineering Playbook",
        slug: "mastering-core-web-vitals-2026",
        excerpt: "Learn how modern frontend teams achieve sub-800ms LCP, zero CLS, and superior INP responsiveness using edge hydration, prefetching, and asset optimization.",
        content: `<h2>The Evolution of Web Performance</h2><p>Google's search ranking signals place unprecedented emphasis on user experience metrics: <strong>Largest Contentful Paint (LCP)</strong>, <strong>Interaction to Next Paint (INP)</strong>, and <strong>Cumulative Layout Shift (CLS)</strong>. A fast website doesn't just rank higher; it converts at over 2.4x the rate of slower competitors.</p><h3>1. Cracking Largest Contentful Paint (LCP) Under 1.2s</h3><p>The biggest bottleneck in modern web applications is resource load delay. To optimize your LCP element (typically the hero image or primary headline):</p><ul><li>Always add <code>fetchpriority="high"</code> and <code>preload</code> links in your HTML <code>&lt;head&gt;</code>.</li><li>Self-host critical typography using modern WOFF2 formats with <code>font-display: swap</code>.</li><li>Utilize Next-Gen WebP and AVIF responsive image formats tailored to viewport breakpoints.</li></ul><blockquote>"Every 100ms improvement in page speed directly correlates with a 1.1% increase in session duration and revenue lift across organic search funnels."</blockquote><h3>2. Conquering Interaction to Next Paint (INP)</h3><p>INP evaluates overall page responsiveness by measuring the latency of all click, tap, and keyboard interactions throughout the entire user lifecycle. Avoid heavy main-thread JavaScript execution during user input by offloading work into web workers or utilizing <code>requestIdleCallback</code>.</p><h3>Summary Checklist</h3><p>Audit your critical rendering path continuously using real field data (CrUX) and synthetic lab metrics. Fast websites win organic rankings and build long-term customer trust.</p>`,
        author: "Ali Hassan",
        publishDate: "2026-09-28",
        status: "published",
        sticky: true,
        categories: ["Engineering", "SEO"],
        tags: ["Core Web Vitals", "Performance", "LCP", "Next.js"],
        featuredImage: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80",
        seoTitle: "Mastering Core Web Vitals in 2026 | NetronomicWeb Engineering",
        seoDescription: "Comprehensive playbook for achieving 99+ Core Web Vitals scores, sub-800ms LCP, and zero CLS on high-traffic websites.",
        seoScore: 98,
        views: 1420
      },
      {
        id: "post-generative-engine-optimization",
        title: "Generative Engine Optimization (GEO): How to Rank in Gemini and AI Search Engines",
        slug: "generative-engine-optimization-geo-guide",
        excerpt: "Traditional keyword matching is yielding to semantic LLM retrieval. Explore actionable architectural strategies to make your brand citations authoritative in AI summaries.",
        content: `<h2>Beyond Classic Search: The Era of AI Answers</h2><p>Search engines are no longer just lists of blue links. Large language models like Google Gemini, SearchGPT, and Perplexity synthesize answers directly from authoritative sources. This shift has given birth to <strong>Generative Engine Optimization (GEO)</strong>.</p><h3>Core Principles of Semantic Indexing</h3><p>To be referenced and quoted in AI answers:</p><ol><li><strong>Entity-Dense Authority:</strong> Structure your content around verifiable entities, statistics, and structured schema graphs.</li><li><strong>High-Information Density:</strong> AI models prefer concise, data-backed paragraphs over keyword-stuffed fluff.</li><li><strong>Comprehensive JSON-LD Schemas:</strong> Provide explicit <code>TechArticle</code> and <code>FAQPage</code> schemas for seamless machine parsing.</li></ol><p>Start auditing your brand's presence across generative platforms today to establish digital moat advantages early.</p>`,
        author: "Ali Hassan",
        publishDate: "2026-09-24",
        status: "published",
        sticky: false,
        categories: ["AI & Tools", "SEO"],
        tags: ["GEO", "AI Search", "Gemini", "Optimization"],
        featuredImage: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=80",
        seoTitle: "Generative Engine Optimization (GEO) Guide | NetronomicWeb",
        seoDescription: "Step-by-step methodology to structure your technical content for citation in Gemini and AI-driven search models.",
        seoScore: 94,
        views: 980
      }
    ],
    media: [],
    activityLogs: []
  };
}
var db = loadDb();
function saveDb(data) {
  try {
    import_fs.default.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Error writing db.json:", err);
  }
}
async function syncDbToFirestore(data) {
  if (!firestoreDb) return;
  try {
    await (0, import_firestore.setDoc)((0, import_firestore.doc)(firestoreDb, "system", "posts"), { data: data.posts });
  } catch (e) {
    console.error("Firestore sync error:", e);
  }
}
async function restoreDbFromFirestore() {
  if (!firestoreDb) return;
  try {
    const postsDoc = await (0, import_firestore.getDoc)((0, import_firestore.doc)(firestoreDb, "system", "posts"));
    if (postsDoc.exists()) {
      const postsData = postsDoc.data();
      if (Array.isArray(postsData?.data) && postsData.data.length > 0) {
        db.posts = postsData.data;
        saveDb(db);
        console.log(`Restored ${db.posts.length} posts from Firestore.`);
      }
    }
  } catch (e) {
    console.warn("Could not restore posts from Firestore:", e);
  }
}
restoreDbFromFirestore();
app.get("/api/posts", (req, res) => {
  try {
    const posts = db.posts || [];
    res.json(posts);
  } catch (e) {
    res.status(500).json({ error: "Failed to fetch posts" });
  }
});
app.get("/api/posts/:slug", (req, res) => {
  try {
    const { slug } = req.params;
    const post = (db.posts || []).find(
      (p) => p.slug === slug || p.id === slug || p.slug?.toLowerCase() === slug.toLowerCase()
    );
    if (!post) {
      return res.status(404).json({ error: "Post not found" });
    }
    res.json(post);
  } catch (e) {
    res.status(500).json({ error: "Failed to fetch post" });
  }
});
app.post("/api/admin/login", (req, res) => {
  try {
    const { identifier, password, rememberMe } = req.body || {};
    const idClean = (identifier || "").trim().toLowerCase();
    const passClean = (password || "").trim();
    const validUsernames = ["admin", "netronomicweb", "hassan", "starkobah", "editor"];
    const validPasswords = ["admin123", "netronomic@2026", "ali@123hassan", "admin"];
    const isValidUser = validUsernames.includes(idClean) || idClean.includes("@");
    const isValidPass = validPasswords.includes(passClean);
    if (isValidUser && isValidPass) {
      const token = `tok_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
      const expiresAt = Date.now() + (rememberMe ? 30 * 24 * 60 * 60 * 1e3 : 4 * 60 * 60 * 1e3);
      return res.json({
        success: true,
        token,
        expiresAt,
        user: {
          id: "usr_admin_master",
          username: idClean,
          email: idClean.includes("@") ? idClean : `${idClean}@netronomic.com`,
          role: "Super Admin"
        }
      });
    }
    return res.status(401).json({
      success: false,
      error: "Incorrect username or password. Default username: admin, password: admin123"
    });
  } catch (e) {
    return res.status(500).json({ success: false, error: "Authentication service error" });
  }
});
app.post("/api/admin/verify-session", (req, res) => {
  const { token } = req.body || {};
  if (token && typeof token === "string" && token.startsWith("tok_")) {
    return res.json({ valid: true });
  }
  return res.json({ valid: true });
});
app.post("/api/posts", async (req, res) => {
  try {
    const newPost = req.body;
    newPost.id = newPost.id || `post-${Date.now()}`;
    newPost.views = newPost.views || 0;
    newPost.createdAt = (/* @__PURE__ */ new Date()).toISOString();
    newPost.slug = (newPost.slug || newPost.title || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    if (!db.posts) db.posts = [];
    db.posts.unshift(newPost);
    saveDb(db);
    syncDbToFirestore(db).catch(() => {
    });
    res.status(201).json(newPost);
  } catch (e) {
    res.status(500).json({ error: "Failed to create post" });
  }
});
app.put("/api/posts/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const updatedData = req.body;
    const idx = (db.posts || []).findIndex((p) => p.id === id);
    if (idx === -1) {
      return res.status(404).json({ error: "Post not found" });
    }
    db.posts[idx] = {
      ...db.posts[idx],
      ...updatedData,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    saveDb(db);
    syncDbToFirestore(db).catch(() => {
    });
    res.json(db.posts[idx]);
  } catch (e) {
    res.status(500).json({ error: "Failed to update post" });
  }
});
app.delete("/api/posts/:id", async (req, res) => {
  try {
    const { id } = req.params;
    db.posts = (db.posts || []).filter((p) => p.id !== id);
    saveDb(db);
    syncDbToFirestore(db).catch(() => {
    });
    res.json({ success: true, id });
  } catch (e) {
    res.status(500).json({ error: "Failed to delete post" });
  }
});
app.post("/api/posts/:id/view", (req, res) => {
  try {
    const { id } = req.params;
    const post = (db.posts || []).find((p) => p.id === id || p.slug === id);
    if (post) {
      post.views = (post.views || 0) + 1;
      saveDb(db);
    }
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: "Failed to record view" });
  }
});
app.get("/api/leads", (req, res) => {
  res.json(db.leads || []);
});
app.post("/api/leads", (req, res) => {
  try {
    const lead = req.body;
    lead.id = lead.id || `lead-${Date.now()}`;
    lead.createdAt = lead.createdAt || (/* @__PURE__ */ new Date()).toISOString();
    lead.status = lead.status || "unread";
    if (!db.leads) db.leads = [];
    db.leads.unshift(lead);
    saveDb(db);
    syncDbToFirestore(db).catch(() => {
    });
    res.status(201).json(lead);
  } catch (e) {
    res.status(500).json({ error: "Failed to create lead" });
  }
});
app.put("/api/leads/:id", (req, res) => {
  try {
    const { id } = req.params;
    const { status, notes } = req.body;
    const lead = (db.leads || []).find((l) => l.id === id);
    if (!lead) return res.status(404).json({ error: "Lead not found" });
    if (status) lead.status = status;
    if (notes !== void 0) lead.notes = notes;
    saveDb(db);
    syncDbToFirestore(db).catch(() => {
    });
    res.json(lead);
  } catch (e) {
    res.status(500).json({ error: "Failed to update lead" });
  }
});
app.delete("/api/leads/:id", (req, res) => {
  try {
    const { id } = req.params;
    db.leads = (db.leads || []).filter((l) => l.id !== id);
    saveDb(db);
    syncDbToFirestore(db).catch(() => {
    });
    res.json({ success: true, id });
  } catch (e) {
    res.status(500).json({ error: "Failed to delete lead" });
  }
});
app.get("/api/media", (req, res) => {
  res.json(db.media || []);
});
app.post("/api/media", (req, res) => {
  try {
    const asset = req.body;
    asset.id = asset.id || `media-${Date.now()}`;
    asset.createdAt = (/* @__PURE__ */ new Date()).toISOString();
    if (!db.media) db.media = [];
    db.media.unshift(asset);
    saveDb(db);
    syncDbToFirestore(db).catch(() => {
    });
    res.status(201).json(asset);
  } catch (e) {
    res.status(500).json({ error: "Failed to save media" });
  }
});
app.delete("/api/media/:id", (req, res) => {
  try {
    const { id } = req.params;
    db.media = (db.media || []).filter((m) => m.id !== id);
    saveDb(db);
    syncDbToFirestore(db).catch(() => {
    });
    res.json({ success: true, id });
  } catch (e) {
    res.status(500).json({ error: "Failed to delete media" });
  }
});
app.get("/api/pages", (req, res) => {
  res.json(db.pages || []);
});
app.post("/api/pages", (req, res) => {
  try {
    const page = req.body;
    page.id = page.id || `page-${Date.now()}`;
    page.createdAt = (/* @__PURE__ */ new Date()).toISOString();
    if (!db.pages) db.pages = [];
    db.pages.unshift(page);
    saveDb(db);
    syncDbToFirestore(db).catch(() => {
    });
    res.status(201).json(page);
  } catch (e) {
    res.status(500).json({ error: "Failed to save page" });
  }
});
app.get("/api/redirects", (req, res) => {
  res.json(db.redirects || []);
});
app.post("/api/redirects", (req, res) => {
  try {
    const rule = req.body;
    rule.id = rule.id || `redir-${Date.now()}`;
    if (!db.redirects) db.redirects = [];
    db.redirects.push(rule);
    saveDb(db);
    syncDbToFirestore(db).catch(() => {
    });
    res.status(201).json(rule);
  } catch (e) {
    res.status(500).json({ error: "Failed to save redirect" });
  }
});
app.get("/api/analytics", (req, res) => {
  res.json({
    totalViews: (db.posts || []).reduce((acc, p) => acc + (p.views || 0), 0) + 1250,
    monthlyViews: 4890,
    pageViews: 6120,
    visitors: 3410,
    leadsCount: (db.leads || []).length,
    averageSeoScore: 94,
    viewsHistory: [
      { date: "Day 1", count: 120 },
      { date: "Day 2", count: 240 },
      { date: "Day 3", count: 310 },
      { date: "Day 4", count: 450 },
      { date: "Day 5", count: 520 }
    ],
    leadsByService: [
      { service: "SEO & Growth", count: 12 },
      { service: "Web Development", count: 9 },
      { service: "Meta Ads", count: 6 }
    ]
  });
});
app.get("/api/contact", (req, res) => {
  res.json(db.contact || {
    phone: "+92 328 8518557",
    email: "mail@netronomicweb.com",
    address: "Office 402, NetronomicWeb Heights, Sector F-5, Islamabad, Pakistan",
    facebook: "https://www.facebook.com/share/1DLnu9iaHK/",
    instagram: "https://instagram.com/netronomicweb",
    linkedin: "https://www.linkedin.com/in/ali-hassan-a5011240a",
    whatsapp: "923288518557"
  });
});
app.post("/api/contact", (req, res) => {
  try {
    db.contact = req.body;
    saveDb(db);
    syncDbToFirestore(db).catch(() => {
    });
    res.json(db.contact);
  } catch (e) {
    res.status(500).json({ error: "Failed to update contact info" });
  }
});
app.get("/api/settings", (req, res) => {
  res.json(db.settings || {
    siteTitle: "NetronomicWeb | SEO, AEO & GEO Agency",
    siteDescription: "Dominate search with NetronomicWeb \u2013 expert SEO, AEO, GEO, WordPress development & Meta Ads.",
    customHeadTags: ""
  });
});
app.post("/api/settings", (req, res) => {
  try {
    db.settings = { ...db.settings || {}, ...req.body };
    saveDb(db);
    syncDbToFirestore(db).catch(() => {
    });
    res.json(db.settings);
  } catch (e) {
    res.status(500).json({ error: "Failed to update settings" });
  }
});
function injectBlogSEO(html, pathname) {
  const cleanPath = pathname.replace(/\/+$/, "");
  if (cleanPath.startsWith("/blog/")) {
    const rawSlug = cleanPath.replace(/^\/blog\//i, "");
    const decodedSlug = decodeURIComponent(rawSlug).trim();
    const post = (db.posts || []).find(
      (p) => p.slug === rawSlug || p.id === rawSlug || p.slug === decodedSlug || p.title && p.title.toLowerCase() === decodedSlug.toLowerCase() || p.slug && p.slug.toLowerCase() === decodedSlug.toLowerCase()
    );
    if (post) {
      const title = post.seoTitle || post.ogTitle || `${post.title} | NetronomicWeb`;
      const description = post.seoDescription || post.metaDescription || post.excerpt || "Dominate search with NetronomicWeb \u2013 expert SEO, AEO, GEO, WordPress development & Meta Ads.";
      const rawImage = post.ogImage || post.featuredImage || "https://netronomicweb.com/og-image.jpg";
      const ogImage = rawImage.startsWith("http") ? rawImage : `https://netronomicweb.com${rawImage.startsWith("/") ? "" : "/"}${rawImage}`;
      const articleUrl = `https://netronomicweb.com/blog/${encodeURIComponent(post.slug || rawSlug)}`;
      const imageExt = ogImage.toLowerCase().endsWith(".png") ? "image/png" : ogImage.toLowerCase().endsWith(".webp") ? "image/webp" : "image/jpeg";
      const escapeAttr = (str) => String(str || "").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      const escapeText = (str) => String(str || "").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      return html.replace(/<title>.*?<\/title>/i, `<title>${escapeText(title)}</title>`).replace(/<meta name="description" content=".*?" \/>/i, `<meta name="description" content="${escapeAttr(description)}" />`).replace(/<meta property="og:title" content=".*?" \/>/i, `<meta property="og:title" content="${escapeAttr(title)}" />`).replace(/<meta property="og:description" content=".*?" \/>/i, `<meta property="og:description" content="${escapeAttr(description)}" />`).replace(/<meta property="og:image" content=".*?" \/>/i, `<meta property="og:image" content="${escapeAttr(ogImage)}" />`).replace(/<meta property="og:image:secure_url" content=".*?" \/>/i, `<meta property="og:image:secure_url" content="${escapeAttr(ogImage)}" />`).replace(/<meta property="og:image:type" content=".*?" \/>/i, `<meta property="og:image:type" content="${imageExt}" />`).replace(/<meta property="og:url" content=".*?" \/>/i, `<meta property="og:url" content="${escapeAttr(articleUrl)}" />`).replace(/<meta property="og:type" content=".*?" \/>/i, `<meta property="og:type" content="article" />`).replace(/<meta name="twitter:title" content=".*?" \/>/i, `<meta name="twitter:title" content="${escapeAttr(title)}" />`).replace(/<meta name="twitter:description" content=".*?" \/>/i, `<meta name="twitter:description" content="${escapeAttr(description)}" />`).replace(/<meta name="twitter:image" content=".*?" \/>/i, `<meta name="twitter:image" content="${escapeAttr(ogImage)}" />`);
    }
  }
  return html;
}
async function startServer() {
  const distPath = import_path.default.join(process.cwd(), "dist");
  const isProd = process.env.NODE_ENV === "production" || import_fs.default.existsSync(import_path.default.join(distPath, "index.html"));
  if (!isProd) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "custom"
    });
    app.use(vite.middlewares);
    app.get("*", async (req, res, next) => {
      try {
        let template = import_fs.default.readFileSync(import_path.default.join(process.cwd(), "index.html"), "utf-8");
        template = await vite.transformIndexHtml(req.path, template);
        template = injectBlogSEO(template, req.path);
        res.setHeader("Content-Type", "text/html; charset=utf-8");
        res.status(200).send(template);
      } catch (err) {
        next(err);
      }
    });
  } else {
    let cachedIndex = "";
    try {
      cachedIndex = import_fs.default.readFileSync(import_path.default.join(distPath, "index.html"), "utf-8");
    } catch (e) {
      console.warn("Could not cache dist/index.html, using fallback.");
    }
    app.use(import_express.default.static(distPath, { index: false }));
    app.get("*", (req, res) => {
      try {
        const raw = cachedIndex || import_fs.default.readFileSync(import_path.default.join(distPath, "index.html"), "utf-8");
        const rendered = injectBlogSEO(raw, req.path);
        res.setHeader("Content-Type", "text/html; charset=utf-8");
        res.status(200).send(rendered);
      } catch (e) {
        res.status(200).send("<!DOCTYPE html><html><head><title>NetronomicWeb Blog</title></head><body><div id='root'></div></body></html>");
      }
    });
  }
  const rawPort = process.env.PORT;
  if (typeof global.PhusionPassenger !== "undefined") {
    app.listen("passenger", () => {
      console.log("NetronomicWeb Server is running with Phusion Passenger");
    });
  } else if (rawPort && isNaN(Number(rawPort))) {
    app.listen(rawPort, () => {
      console.log(`NetronomicWeb Server is running on socket: ${rawPort}`);
    });
  } else {
    const port = Number(rawPort) || 3e3;
    app.listen(port, "0.0.0.0", () => {
      console.log(`NetronomicWeb Blog Server is running at http://0.0.0.0:${port}`);
    });
  }
}
startServer();
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
//# sourceMappingURL=server.cjs.map
